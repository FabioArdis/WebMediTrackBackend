--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE meditrack;
--
-- Name: meditrack; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE meditrack WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE meditrack OWNER TO postgres;

\connect meditrack

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plans; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA plans;


ALTER SCHEMA plans OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: users; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA users;


ALTER SCHEMA users OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: plans; Type: TABLE; Schema: plans; Owner: postgres
--

CREATE TABLE plans.plans (
    plan_id integer NOT NULL,
    name character varying(255),
    length integer,
    type character varying(255)
);


ALTER TABLE plans.plans OWNER TO postgres;

--
-- Name: plans_plan_id_seq; Type: SEQUENCE; Schema: plans; Owner: postgres
--

CREATE SEQUENCE plans.plans_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE plans.plans_plan_id_seq OWNER TO postgres;

--
-- Name: plans_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: plans; Owner: postgres
--

ALTER SEQUENCE plans.plans_plan_id_seq OWNED BY plans.plans.plan_id;


--
-- Name: plansmedicines; Type: TABLE; Schema: plans; Owner: postgres
--

CREATE TABLE plans.plansmedicines (
    plan_id integer NOT NULL,
    medicine_id integer NOT NULL
);


ALTER TABLE plans.plansmedicines OWNER TO postgres;

--
-- Name: admin; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.admin (
    username character varying(255) NOT NULL,
    password character varying(255),
    email character varying(255),
    name character varying(255),
    surname character varying(255),
    birthdate date,
    adminid integer
);


ALTER TABLE users.admin OWNER TO postgres;

--
-- Name: doctor; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.doctor (
    username character varying(255) NOT NULL,
    password character varying(255),
    email character varying(255),
    name character varying(255),
    surname character varying(255),
    birthdate date,
    cf character varying(16),
    doctorid character varying(255),
    spec character varying(255),
    docavailtime character varying(255)
);


ALTER TABLE users.doctor OWNER TO postgres;

--
-- Name: doctor_patients; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.doctor_patients (
    doctor_username character varying(255) NOT NULL,
    patient_username character varying(255) NOT NULL
);


ALTER TABLE users.doctor_patients OWNER TO postgres;

--
-- Name: patient; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.patient (
    username character varying(255) NOT NULL,
    password character varying(255),
    email character varying(255),
    name character varying(255),
    surname character varying(255),
    birthdate date,
    cf character varying(16),
    ts_code character varying(16)
);


ALTER TABLE users.patient OWNER TO postgres;

--
-- Name: therapeutical_plans; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.therapeutical_plans (
    username character varying(255) NOT NULL,
    plan_id integer NOT NULL
);


ALTER TABLE users.therapeutical_plans OWNER TO postgres;

--
-- Name: token_patients; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.token_patients (
    id character varying NOT NULL,
    auth boolean NOT NULL,
    expiration_time date
);


ALTER TABLE users.token_patients OWNER TO postgres;

--
-- Name: plans plan_id; Type: DEFAULT; Schema: plans; Owner: postgres
--

ALTER TABLE ONLY plans.plans ALTER COLUMN plan_id SET DEFAULT nextval('plans.plans_plan_id_seq'::regclass);


--
-- Data for Name: plans; Type: TABLE DATA; Schema: plans; Owner: postgres
--

COPY plans.plans (plan_id, name, length, type) FROM stdin;
\.
COPY plans.plans (plan_id, name, length, type) FROM '$$PATH$$/4833.dat';

--
-- Data for Name: plansmedicines; Type: TABLE DATA; Schema: plans; Owner: postgres
--

COPY plans.plansmedicines (plan_id, medicine_id) FROM stdin;
\.
COPY plans.plansmedicines (plan_id, medicine_id) FROM '$$PATH$$/4836.dat';

--
-- Data for Name: admin; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.admin (username, password, email, name, surname, birthdate, adminid) FROM stdin;
\.
COPY users.admin (username, password, email, name, surname, birthdate, adminid) FROM '$$PATH$$/4829.dat';

--
-- Data for Name: doctor; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.doctor (username, password, email, name, surname, birthdate, cf, doctorid, spec, docavailtime) FROM stdin;
\.
COPY users.doctor (username, password, email, name, surname, birthdate, cf, doctorid, spec, docavailtime) FROM '$$PATH$$/4830.dat';

--
-- Data for Name: doctor_patients; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.doctor_patients (doctor_username, patient_username) FROM stdin;
\.
COPY users.doctor_patients (doctor_username, patient_username) FROM '$$PATH$$/4835.dat';

--
-- Data for Name: patient; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.patient (username, password, email, name, surname, birthdate, cf, ts_code) FROM stdin;
\.
COPY users.patient (username, password, email, name, surname, birthdate, cf, ts_code) FROM '$$PATH$$/4831.dat';

--
-- Data for Name: therapeutical_plans; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.therapeutical_plans (username, plan_id) FROM stdin;
\.
COPY users.therapeutical_plans (username, plan_id) FROM '$$PATH$$/4834.dat';

--
-- Data for Name: token_patients; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.token_patients (id, auth, expiration_time) FROM stdin;
\.
COPY users.token_patients (id, auth, expiration_time) FROM '$$PATH$$/4837.dat';

--
-- Name: plans_plan_id_seq; Type: SEQUENCE SET; Schema: plans; Owner: postgres
--

SELECT pg_catalog.setval('plans.plans_plan_id_seq', 54, true);


--
-- Name: plansmedicines plans_medicines_pkay; Type: CONSTRAINT; Schema: plans; Owner: postgres
--

ALTER TABLE ONLY plans.plansmedicines
    ADD CONSTRAINT plans_medicines_pkay PRIMARY KEY (plan_id, medicine_id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: plans; Owner: postgres
--

ALTER TABLE ONLY plans.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (plan_id);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (username);


--
-- Name: token_patients auth_patients_pk; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.token_patients
    ADD CONSTRAINT auth_patients_pk PRIMARY KEY (id);


--
-- Name: doctor_patients doctor_patients_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.doctor_patients
    ADD CONSTRAINT doctor_patients_pkey PRIMARY KEY (doctor_username, patient_username);


--
-- Name: doctor doctor_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.doctor
    ADD CONSTRAINT doctor_pkey PRIMARY KEY (username);


--
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (username);


--
-- Name: therapeutical_plans therapeutical_plans_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.therapeutical_plans
    ADD CONSTRAINT therapeutical_plans_pkey PRIMARY KEY (username, plan_id);


--
-- Name: plansmedicines plans_medicines_plan_id_fkey; Type: FK CONSTRAINT; Schema: plans; Owner: postgres
--

ALTER TABLE ONLY plans.plansmedicines
    ADD CONSTRAINT plans_medicines_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES plans.plans(plan_id);


--
-- Name: doctor_patients doctor_patients_doctor_username_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.doctor_patients
    ADD CONSTRAINT doctor_patients_doctor_username_fkey FOREIGN KEY (doctor_username) REFERENCES users.doctor(username);


--
-- Name: doctor_patients doctor_patients_patient_username_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.doctor_patients
    ADD CONSTRAINT doctor_patients_patient_username_fkey FOREIGN KEY (patient_username) REFERENCES users.patient(username);


--
-- Name: therapeutical_plans therapeutical_plans_plan_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.therapeutical_plans
    ADD CONSTRAINT therapeutical_plans_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES plans.plans(plan_id);


--
-- Name: therapeutical_plans therapeutical_plans_username_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.therapeutical_plans
    ADD CONSTRAINT therapeutical_plans_username_fkey FOREIGN KEY (username) REFERENCES users.patient(username);


--
-- PostgreSQL database dump complete
--

